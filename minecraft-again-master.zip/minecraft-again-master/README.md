# minecraft-again
yeah I made it again

Minecraft, but it's built on top of a deferred renderer.

![screenshot](images/screenshot.png)

Use the `Makefile` (`$ make`) to build (make **sure** you clone with submodules!). This won't support any platforms other than Mac OS, you'll need to modify `platform_glfw.cpp` yourself to add support.

PLEASE NOTE, this is just some reference code - I will not be supporting it, adding new platforms, fixing bugs, or anything like that - but feel free to browse :)
