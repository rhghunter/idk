#ifndef GFX_BGFX_HPP
#define GFX_BGFX_HPP

#include <bgfx/bgfx.h>
#include <bgfx/platform.h>

#endif
