#ifndef GFX_HPP
#define GFX_HPP

// bgfx platform
#include "gfx/bgfx.hpp"

// gfx headers
#include "gfx/util.hpp"
#include "gfx/renderer.hpp"

#endif
