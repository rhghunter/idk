#ifndef LEVEL_GEN_HPP
#define LEVEL_GEN_HPP

#include "util/util.hpp"

namespace level {
// forward declaration
struct Chunk;

void gen(Chunk &chunk);
}

#endif
